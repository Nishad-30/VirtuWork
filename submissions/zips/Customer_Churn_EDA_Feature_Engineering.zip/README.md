
Customer Churn Prediction – EDA & Feature Engineering

Steps:
1. Place your dataset as 'customer_churn.csv' in this folder
2. Run churn_eda_feature_engineering.py
3. Visualizations and processed data will be generated

Requirements:
- pandas
- numpy
- matplotlib
- seaborn
- scikit-learn
