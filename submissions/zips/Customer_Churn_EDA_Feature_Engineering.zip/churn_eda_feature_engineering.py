
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder, StandardScaler

# Load dataset
df = pd.read_csv("customer_churn.csv")
print(df.head())

# Basic info
print(df.info())
print(df.describe(include='all'))

# Convert TotalCharges to numeric
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
df["TotalCharges"].fillna(df["TotalCharges"].median(), inplace=True)

# Churn distribution
sns.countplot(x="Churn", data=df)
plt.title("Churn Distribution")
plt.show()

# Numerical analysis
num_features = ["tenure", "MonthlyCharges", "TotalCharges"]
for col in num_features:
    sns.boxplot(x="Churn", y=col, data=df)
    plt.title(f"{col} vs Churn")
    plt.show()

# Feature Engineering
df["AvgMonthlySpend"] = df["TotalCharges"] / (df["tenure"] + 1)

service_cols = [
    "PhoneService", "MultipleLines", "InternetService",
    "OnlineSecurity", "OnlineBackup", "DeviceProtection",
    "TechSupport", "StreamingTV", "StreamingMovies"
]

df["ServiceCount"] = df[service_cols].apply(lambda x: sum(x == "Yes"), axis=1)

df["TenureGroup"] = pd.cut(
    df["tenure"],
    bins=[0, 12, 24, 48, 72],
    labels=["0-1yr", "1-2yr", "2-4yr", "4-6yr"]
)

# Encoding
binary_cols = [col for col in df.columns if df[col].nunique() == 2]
le = LabelEncoder()
for col in binary_cols:
    df[col] = le.fit_transform(df[col])

df = pd.get_dummies(df, drop_first=True)

# Scaling
scaler = StandardScaler()
scaled_cols = ["tenure", "MonthlyCharges", "TotalCharges", "AvgMonthlySpend"]
df[scaled_cols] = scaler.fit_transform(df[scaled_cols])

print("EDA and Feature Engineering completed successfully.")
