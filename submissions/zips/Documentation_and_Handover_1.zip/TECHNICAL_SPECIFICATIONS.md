
## Technical Specifications

### Technology Stack
- Python, Pandas, Scikit-learn
- Flask (Model API)
- SQL / Time-Series Database
- Docker & Kubernetes (Deployment)
- Prometheus & Grafana (Monitoring)

### Models Used
- Random Forest Classifier
- Support Vector Machine

### Performance Metrics
- Precision
- Recall
- F1-score
- ROC-AUC
