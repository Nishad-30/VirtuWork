
## User Manual

### Dashboard Usage
1. Select machine ID
2. View real-time risk score
3. Monitor historical sensor trends
4. Receive maintenance alerts

### Risk Levels
- Low: Normal operation
- Medium: Monitor closely
- High: Immediate maintenance recommended
