
## Maintenance & Operations Guide

### Model Retraining
- Retrain every 3–6 months
- Use latest labeled sensor data

### Monitoring
- Track prediction confidence
- Monitor latency & error rates

### Backup & Recovery
- Daily database backups
- Versioned model storage
