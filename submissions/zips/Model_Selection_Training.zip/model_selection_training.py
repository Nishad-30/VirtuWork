
# Model Selection & Training for Predictive Maintenance

import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import classification_report, roc_auc_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier

# Load preprocessed data
df = pd.read_csv("processed_data.csv")

X = df.drop(columns=['failure'])
y = df['failure']

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42
)

# Random Forest
rf = RandomForestClassifier(random_state=42)
rf_params = {
    'n_estimators': [100, 200],
    'max_depth': [None, 10],
    'min_samples_split': [2, 5]
}
rf_grid = GridSearchCV(rf, rf_params, scoring='f1', cv=3)
rf_grid.fit(X_train, y_train)
rf_best = rf_grid.best_estimator_

rf_preds = rf_best.predict(X_test)
print("Random Forest Results")
print(classification_report(y_test, rf_preds))
print("AUC:", roc_auc_score(y_test, rf_best.predict_proba(X_test)[:, 1]))

# Support Vector Machine
svm = SVC(probability=True)
svm_params = {
    'C': [0.1, 1, 10],
    'kernel': ['linear', 'rbf']
}
svm_grid = GridSearchCV(svm, svm_params, scoring='f1', cv=3)
svm_grid.fit(X_train, y_train)
svm_best = svm_grid.best_estimator_

svm_preds = svm_best.predict(X_test)
print("SVM Results")
print(classification_report(y_test, svm_preds))
print("AUC:", roc_auc_score(y_test, svm_best.predict_proba(X_test)[:, 1]))

# Neural Network
mlp = MLPClassifier(max_iter=500, random_state=42)
mlp_params = {
    'hidden_layer_sizes': [(50,), (100,)],
    'alpha': [0.0001, 0.001]
}
mlp_grid = GridSearchCV(mlp, mlp_params, scoring='f1', cv=3)
mlp_grid.fit(X_train, y_train)
mlp_best = mlp_grid.best_estimator_

mlp_preds = mlp_best.predict(X_test)
print("Neural Network Results")
print(classification_report(y_test, mlp_preds))
print("AUC:", roc_auc_score(y_test, mlp_best.predict_proba(X_test)[:, 1]))
