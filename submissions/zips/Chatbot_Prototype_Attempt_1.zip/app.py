from flask import Flask, request, jsonify

app = Flask(__name__)

def detect_intent(message):
    message = message.lower()
    if "order" in message:
        return "order_status", 0.9
    elif "laptop" in message or "product" in message:
        return "product_query", 0.85
    elif "agent" in message or "human" in message:
        return "escalation", 0.95
    elif "hello" in message or "hi" in message:
        return "greeting", 0.9
    else:
        return "unknown", 0.4

def handle_message(user_input):
    intent, confidence = detect_intent(user_input)

    if confidence < 0.6 or intent == "escalation":
        return "Connecting you to a human support agent."

    if intent == "order_status":
        return "Your order is currently being processed."

    if intent == "product_query":
        return "Here are some popular laptops: Dell XPS, MacBook Air, HP Spectre."

    if intent == "greeting":
        return "Hello! How can I help you today?"

    return "Sorry, I didn’t understand that."

@app.route("/chat", methods=["POST"])
def chat():
    user_message = request.json.get("message")
    response = handle_message(user_message)
    return jsonify({"response": response})

if __name__ == "__main__":
    app.run(debug=True)
