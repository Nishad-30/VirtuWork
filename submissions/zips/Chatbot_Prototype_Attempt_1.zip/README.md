# Chatbot Prototype – Attempt 1/3

This is a basic prototype of an AI-Powered Customer Support Chatbot for an E-Commerce Platform.

## Features
- Greeting handling
- FAQ responses
- Order status (mock)
- Product recommendations (rule-based)
- Human escalation logic

## How to Run
1. Install Python 3.9+
2. pip install flask
3. python app.py
4. Open http://127.0.0.1:5000/chat
