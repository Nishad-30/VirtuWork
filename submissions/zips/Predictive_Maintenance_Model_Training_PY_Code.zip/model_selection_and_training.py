
# Model Selection & Training
# Predictive Maintenance System

import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import classification_report, roc_auc_score

# -----------------------------
# 1. Load / Prepare Dataset
# -----------------------------
# NOTE: Replace this synthetic data with real preprocessed dataset

np.random.seed(42)
X = pd.DataFrame(np.random.rand(500, 10), columns=[f"feature_{i}" for i in range(10)])
y = np.random.choice([0, 1], size=500, p=[0.9, 0.1])  # Imbalanced target

# -----------------------------
# 2. Train-Test Split
# -----------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42
)

# -----------------------------
# 3. Random Forest Model
# -----------------------------
rf_model = RandomForestClassifier(
    n_estimators=200,
    class_weight="balanced",
    random_state=42
)

rf_model.fit(X_train, y_train)
rf_preds = rf_model.predict(X_test)
rf_probs = rf_model.predict_proba(X_test)[:, 1]

print("Random Forest Results")
print(classification_report(y_test, rf_preds))
print("ROC-AUC:", roc_auc_score(y_test, rf_probs))

# -----------------------------
# 4. Support Vector Machine Model
# -----------------------------
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

svm_model = SVC(
    kernel="rbf",
    probability=True,
    class_weight="balanced",
    random_state=42
)

svm_model.fit(X_train_scaled, y_train)
svm_preds = svm_model.predict(X_test_scaled)
svm_probs = svm_model.predict_proba(X_test_scaled)[:, 1]

print("\nSVM Results")
print(classification_report(y_test, svm_preds))
print("ROC-AUC:", roc_auc_score(y_test, svm_probs))

# -----------------------------
# 5. Cross-Validation
# -----------------------------
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

rf_cv_f1 = cross_val_score(
    rf_model, X, y, cv=cv, scoring="f1"
)

print("\nCross-Validation (Random Forest)")
print("F1 Scores:", rf_cv_f1)
print("Mean F1:", rf_cv_f1.mean())

# -----------------------------
# 6. Conclusion
# -----------------------------
print(
    "\nConclusion: Random Forest provides strong and stable performance "
    "for predictive maintenance. SVM performs reasonably well but is "
    "more sensitive to feature scaling. LSTM models can be explored in "
    "future iterations for temporal learning."
)
