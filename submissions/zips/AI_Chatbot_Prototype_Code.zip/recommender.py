
def recommend_products(entities):
    return "I recommend checking out our latest smartphones and accessories."
