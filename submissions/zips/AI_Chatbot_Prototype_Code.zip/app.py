
from flask import Flask, request, jsonify
from nlp import detect_intent
from recommender import recommend_products
from orders import get_order_status

app = Flask(__name__)

@app.route("/chat", methods=["POST"])
def chat():
    user_message = request.json.get("message")
    intent, entities = detect_intent(user_message)

    if intent == "product_recommendation":
        response = recommend_products(entities)
    elif intent == "order_status":
        response = get_order_status(entities)
    else:
        response = "I'm sorry, I couldn't understand your request. Connecting you to a human agent."

    return jsonify({"response": response})

if __name__ == "__main__":
    app.run(debug=True)
