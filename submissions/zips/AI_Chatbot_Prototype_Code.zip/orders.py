
def get_order_status(entities):
    return f"Your order {entities.get('order_id')} is currently being processed."
