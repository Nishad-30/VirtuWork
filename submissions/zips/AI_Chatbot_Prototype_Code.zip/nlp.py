
def detect_intent(message):
    message = message.lower()
    if "recommend" in message or "suggest" in message:
        return "product_recommendation", {}
    if "order" in message or "status" in message:
        return "order_status", {"order_id": "12345"}
    return "unknown", {}
