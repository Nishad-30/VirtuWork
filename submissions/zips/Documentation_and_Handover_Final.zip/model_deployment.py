
from flask import Flask, request, jsonify
import joblib
import pandas as pd

app = Flask(__name__)

model = joblib.load("random_forest_model.pkl")
scaler = joblib.load("scaler.pkl")

@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json()
    df = pd.DataFrame([data])
    X_scaled = scaler.transform(df)
    pred = int(model.predict(X_scaled)[0])
    prob = float(model.predict_proba(X_scaled)[0][1])

    return jsonify({
        "failure_prediction": pred,
        "failure_probability": round(prob, 4)
    })

if __name__ == "__main__":
    app.run()
