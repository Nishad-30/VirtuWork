
## Maintenance Procedures

- Retrain model every 3–6 months
- Monitor prediction distribution for drift
- Backup model artifacts and logs
