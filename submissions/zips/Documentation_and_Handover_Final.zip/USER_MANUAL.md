
## User Manual

### Running the System
1. Train the model using `model_training.py`
2. Start the API with `model_deployment.py`
3. Send sensor data to `/predict` endpoint

### API Usage
POST /predict
Input:
{
  "vibration": 0.4,
  "temperature": 72,
  "pressure": 101
}

Output:
{
  "failure_prediction": 1,
  "failure_probability": 0.82
}

### Interpretation
- 0 → Normal operation
- 1 → Failure risk detected
