
- [x] Detailed documentation
- [x] Preprocessing & training scripts
- [x] Deployment-ready API
- [x] Sample dataset
- [x] Notebook
