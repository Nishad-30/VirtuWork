
## Technical Specifications

### Tech Stack
- Python 3.10
- Pandas, NumPy
- Scikit-learn
- Flask
- Joblib
- SQL / Time-series DB (production)

### Data Preprocessing
- Missing value handling (median imputation)
- Feature scaling (StandardScaler)
- Rolling statistics (mean, std)

### Model Training
- Random Forest Classifier
- Hyperparameter tuning
- Model persistence using joblib

### Deployment
- REST API (Flask)
- JSON-based input/output
- Logging and error handling
