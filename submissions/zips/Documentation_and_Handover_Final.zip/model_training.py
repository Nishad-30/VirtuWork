
import pandas as pd
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# Load data
df = pd.read_csv("sample_sensor_data.csv")

# Preprocessing
df.fillna(df.median(), inplace=True)
X = df.drop("failure_label", axis=1)
y = df["failure_label"]

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Train model
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)
model = RandomForestClassifier(n_estimators=200, random_state=42)
model.fit(X_train, y_train)

# Persist artifacts
joblib.dump(model, "random_forest_model.pkl")
joblib.dump(scaler, "scaler.pkl")
