
## System Overview

The system predicts equipment failures using sensor data (vibration, temperature, pressure).
It follows a full ML lifecycle:
1. Data ingestion & preprocessing
2. Feature engineering
3. Model training & persistence
4. REST-based deployment
5. Monitoring & retraining

The design supports scalability, reliability, and real-time inference.
