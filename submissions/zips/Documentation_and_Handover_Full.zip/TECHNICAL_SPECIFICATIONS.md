
## Technical Specifications
- Language: Python
- ML: Scikit-learn
- API: Flask
- Deployment: Docker-ready
