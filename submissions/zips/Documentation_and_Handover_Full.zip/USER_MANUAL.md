
## User Manual
1. Start API service
2. Send sensor data to /predict endpoint
3. View failure risk
