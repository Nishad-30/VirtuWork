
# Model Training Script
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

df = pd.read_csv("sample_sensor_data.csv")
X = df.drop("failure_label", axis=1)
y = df["failure_label"]

model = RandomForestClassifier()
model.fit(X, y)
