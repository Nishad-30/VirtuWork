
## System Overview
This system predicts equipment failures using machine learning on sensor data.
