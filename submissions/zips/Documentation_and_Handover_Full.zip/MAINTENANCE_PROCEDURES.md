
## Maintenance Procedures
- Retrain model every 3–6 months
- Monitor logs and drift
