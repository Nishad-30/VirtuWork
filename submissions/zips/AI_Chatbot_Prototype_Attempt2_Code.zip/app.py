
from flask import Flask, request, jsonify
from nlp_ml import predict_intent
from responses import generate_response

app = Flask(__name__)

@app.route("/chat", methods=["POST"])
def chat():
    user_message = request.json.get("message")
    intent, confidence = predict_intent(user_message)

    if confidence < 0.5:
        return jsonify({"response": "I'm connecting you to a human agent for better assistance."})

    response = generate_response(intent, user_message)
    return jsonify({"response": response})

if __name__ == "__main__":
    app.run(debug=True)
