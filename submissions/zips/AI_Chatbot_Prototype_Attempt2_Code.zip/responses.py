
def generate_response(intent, message):
    if intent == "recommendation":
        return "I recommend checking out our best-selling electronics and accessories."
    elif intent == "order_status":
        return "Please provide your order ID to check the status."
    elif intent == "support":
        return "Sure, I'm here to help. Could you please describe your issue?"
    return "I'm not sure how to help with that."
