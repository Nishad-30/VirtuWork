
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

training_data = [
    ("recommend a product", "recommendation"),
    ("suggest me something", "recommendation"),
    ("where is my order", "order_status"),
    ("track my order", "order_status"),
    ("i need help", "support")
]

texts, labels = zip(*training_data)

vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(texts)

model = LogisticRegression()
model.fit(X, labels)

def predict_intent(text):
    X_test = vectorizer.transform([text])
    probs = model.predict_proba(X_test)[0]
    confidence = max(probs)
    intent = model.classes_[probs.argmax()]
    return intent, confidence
