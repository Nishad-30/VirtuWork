
import pandas as pd
import numpy as np

# Load churn predictions
# Expected columns: CustomerID, churn_probability
df = pd.read_csv("churn_predictions.csv")

# Define risk segments
df["RiskSegment"] = pd.cut(
    df["churn_probability"],
    bins=[0, 0.3, 0.6, 1.0],
    labels=["Low Risk", "Medium Risk", "High Risk"]
)

# Define retention actions
def retention_action(row):
    if row["RiskSegment"] == "High Risk":
        return "Offer discount + priority support + contract upgrade"
    elif row["RiskSegment"] == "Medium Risk":
        return "Personalized plan recommendation + loyalty points"
    else:
        return "Regular engagement emails and service tips"

df["RetentionAction"] = df.apply(retention_action, axis=1)

# Estimated retention cost
cost_map = {
    "Offer discount + priority support + contract upgrade": 50,
    "Personalized plan recommendation + loyalty points": 20,
    "Regular engagement emails and service tips": 5
}

df["EstimatedCost"] = df["RetentionAction"].map(cost_map)

# Expected value uplift
df["ExpectedValueUplift"] = df["churn_probability"] * 100

# Save output
df.to_csv("retention_strategy_output.csv", index=False)

print("Retention strategy optimization completed successfully.")
print(df.head())
