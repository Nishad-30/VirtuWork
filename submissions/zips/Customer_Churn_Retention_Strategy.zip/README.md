
Retention Strategy Optimization

Files:
- churn_retention_strategy.py : Generates retention actions based on churn probability
- retention_strategy_output.csv : Final strategy output
- strategy_document.txt : Retention strategy explanation

Input:
- churn_predictions.csv (CustomerID, churn_probability)

Run:
python churn_retention_strategy.py
