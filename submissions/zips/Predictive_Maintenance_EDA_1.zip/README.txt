
Predictive Maintenance – EDA Package

Contents:
1. data_extraction.sql – SQL query for data collection
2. eda_pipeline.py – Python EDA & preprocessing script

Steps:
- Run SQL to export CSV
- Place CSV as predictive_maintenance_data.csv
- Run Python script
