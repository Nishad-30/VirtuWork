
-- Data Extraction Query
SELECT 
    s.machine_id,
    s.timestamp,
    s.vibration,
    s.temperature,
    s.pressure,
    m.last_maintenance_date,
    f.failure_time,
    f.failure_type
FROM sensor_readings s
LEFT JOIN maintenance_logs m
    ON s.machine_id = m.machine_id
LEFT JOIN failure_history f
    ON s.machine_id = f.machine_id
ORDER BY s.machine_id, s.timestamp;
