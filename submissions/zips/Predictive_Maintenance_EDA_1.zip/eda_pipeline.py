
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler

df = pd.read_csv("predictive_maintenance_data.csv", parse_dates=["timestamp"])
df.sort_values(["machine_id", "timestamp"], inplace=True)

df[['vibration','temperature','pressure']] = (
    df.groupby('machine_id')[['vibration','temperature','pressure']]
      .apply(lambda x: x.interpolate())
)

df['failure_label'] = 0

window = 10
df['vibration_mean'] = df.groupby('machine_id')['vibration'].rolling(window).mean().reset_index(0,drop=True)
df['vibration_std'] = df.groupby('machine_id')['vibration'].rolling(window).std().reset_index(0,drop=True)

scaler = StandardScaler()
num_cols = ['vibration','temperature','pressure','vibration_mean','vibration_std']
df[num_cols] = scaler.fit_transform(df[num_cols])

print(df.head())
