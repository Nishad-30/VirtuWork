
import torch
from chatbot import Chatbot
from transformers import AutoTokenizer, AutoModelForSequenceClassification

def run_tests():
    tokenizer = AutoTokenizer.from_pretrained('distilbert-base-uncased')
    model = AutoModelForSequenceClassification.from_pretrained('distilbert-base-uncased', num_labels=8)
    chatbot = Chatbot(model, tokenizer)

    test_queries = [
        "Where is my order?",
        "Can you recommend a laptop?",
        "I want to update my order",
        "Hello",
        ""
    ]

    for query in test_queries:
        try:
            response = chatbot.respond(query)
            print(f"Query: {query} -> Intent: {response}")
        except Exception as e:
            print(f"Error handling query '{query}': {e}")

if __name__ == "__main__":
    run_tests()
