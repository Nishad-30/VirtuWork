
def log_feedback(query, predicted_intent, feedback):
    with open("feedback_log.txt", "a") as f:
        f.write(f"{query},{predicted_intent},{feedback}\n")
