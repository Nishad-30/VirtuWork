
Model Deployment & Integration – Predictive Maintenance

Files:
- model_deployment_integration.py

How to run:
1. Place trained model (random_forest_model.pkl) and scaler (scaler.pkl) in the same directory
2. Install dependencies: flask, pandas, scikit-learn, joblib
3. Run: python model_deployment_integration.py

Endpoints:
- GET /health
- POST /predict
