
# Predictive Maintenance – Model Deployment & Integration

import joblib
import logging
import time
import pandas as pd
from flask import Flask, request, jsonify

# Logging configuration
logging.basicConfig(
    filename="model_inference.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

# Load trained model and scaler
model = joblib.load("random_forest_model.pkl")
scaler = joblib.load("scaler.pkl")

app = Flask(__name__)

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "running"}), 200

@app.route("/predict", methods=["POST"])
def predict():
    start_time = time.time()
    try:
        data = request.get_json()
        df = pd.DataFrame([data])
        df_scaled = scaler.transform(df)

        prediction = model.predict(df_scaled)[0]
        probability = model.predict_proba(df_scaled)[0][1]

        response_time = round(time.time() - start_time, 4)

        logging.info(
            f"Prediction={prediction}, Probability={probability}, ResponseTime={response_time}s"
        )

        return jsonify({
            "failure_prediction": int(prediction),
            "failure_probability": float(probability),
            "response_time_sec": response_time
        })
    except Exception as e:
        logging.error(str(e))
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
