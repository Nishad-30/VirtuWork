
# Model Evaluation & Refinement
# Predictive Maintenance System

import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split, GridSearchCV, StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import (
    classification_report,
    roc_auc_score,
    confusion_matrix
)

# -----------------------------
# 1. Load / Prepare Dataset
# -----------------------------
# Replace this synthetic data with real preprocessed dataset

np.random.seed(42)
X = pd.DataFrame(np.random.rand(500, 10), columns=[f"feature_{i}" for i in range(10)])
y = np.random.choice([0, 1], size=500, p=[0.9, 0.1])

# -----------------------------
# 2. Train-Test Split
# -----------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42
)

# -----------------------------
# 3. Baseline Random Forest
# -----------------------------
rf_baseline = RandomForestClassifier(
    n_estimators=200,
    class_weight="balanced",
    random_state=42
)

rf_baseline.fit(X_train, y_train)
rf_preds = rf_baseline.predict(X_test)
rf_probs = rf_baseline.predict_proba(X_test)[:, 1]

print("Baseline Random Forest Performance")
print(classification_report(y_test, rf_preds))
print("ROC-AUC:", roc_auc_score(y_test, rf_probs))
print("Confusion Matrix:\n", confusion_matrix(y_test, rf_preds))

# -----------------------------
# 4. Hyperparameter Tuning
# -----------------------------
param_grid = {
    "n_estimators": [200, 300],
    "max_depth": [None, 10, 20],
    "min_samples_split": [2, 5]
}

cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

grid_search = GridSearchCV(
    RandomForestClassifier(class_weight="balanced", random_state=42),
    param_grid=param_grid,
    scoring="f1",
    cv=cv,
    n_jobs=-1
)

grid_search.fit(X_train, y_train)

best_rf = grid_search.best_estimator_

# -----------------------------
# 5. Refined Model Evaluation
# -----------------------------
best_preds = best_rf.predict(X_test)
best_probs = best_rf.predict_proba(X_test)[:, 1]

print("\nRefined Random Forest Performance")
print("Best Parameters:", grid_search.best_params_)
print(classification_report(y_test, best_preds))
print("ROC-AUC:", roc_auc_score(y_test, best_probs))
print("Confusion Matrix:\n", confusion_matrix(y_test, best_preds))

# -----------------------------
# 6. Threshold Optimization
# -----------------------------
threshold = 0.4
adjusted_preds = (best_probs >= threshold).astype(int)

print("\nThreshold-Optimized Results (threshold = 0.4)")
print(classification_report(y_test, adjusted_preds))
print("Confusion Matrix:\n", confusion_matrix(y_test, adjusted_preds))

# -----------------------------
# 7. Conclusion
# -----------------------------
print(
    "\nConclusion: Hyperparameter tuning and threshold optimization "
    "improved recall and overall robustness. The refined Random Forest "
    "model is suitable for deployment in predictive maintenance scenarios."
)
