
Customer Churn Prediction – Model Development & Training

Files:
- churn_model_training.py : Trains Logistic Regression and Random Forest models
- processed_churn_data.csv : Input dataset (generated after EDA & Feature Engineering)

Steps:
1. Place processed_churn_data.csv in the same folder
2. Run: python churn_model_training.py

Requirements:
- pandas
- scikit-learn
