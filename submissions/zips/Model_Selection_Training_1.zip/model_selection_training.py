
# Predictive Maintenance – Model Selection & Training

import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split, GridSearchCV, StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report, roc_auc_score

# Load dataset
df = pd.read_csv("predictive_maintenance_data.csv")

TARGET = "failure_label"
X = df.drop(columns=[TARGET]).select_dtypes(include=np.number)
y = df[TARGET]

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42
)

# Cross-validation strategy
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

# Random Forest Model
rf = RandomForestClassifier(class_weight="balanced", random_state=42)
rf_params = {
    "n_estimators": [100, 200],
    "max_depth": [None, 10, 20]
}

rf_grid = GridSearchCV(rf, rf_params, scoring="f1", cv=cv, n_jobs=-1)
rf_grid.fit(X_train, y_train)

rf_best = rf_grid.best_estimator_
rf_preds = rf_best.predict(X_test)
rf_probs = rf_best.predict_proba(X_test)[:, 1]

print("Random Forest Results")
print(classification_report(y_test, rf_preds))
print("ROC-AUC:", roc_auc_score(y_test, rf_probs))

# SVM Model
svm_pipeline = Pipeline([
    ("scaler", StandardScaler()),
    ("svm", SVC(probability=True, class_weight="balanced"))
])

svm_params = {
    "svm__C": [0.1, 1, 10],
    "svm__kernel": ["linear", "rbf"]
}

svm_grid = GridSearchCV(svm_pipeline, svm_params, scoring="f1", cv=cv, n_jobs=-1)
svm_grid.fit(X_train, y_train)

svm_best = svm_grid.best_estimator_
svm_preds = svm_best.predict(X_test)
svm_probs = svm_best.predict_proba(X_test)[:, 1]

print("SVM Results")
print(classification_report(y_test, svm_preds))
print("ROC-AUC:", roc_auc_score(y_test, svm_probs))

print("Conclusion: Random Forest is preferred for deployment.")
