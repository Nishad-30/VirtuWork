
Model Selection & Training – Predictive Maintenance

Files:
- model_selection_training.py

Steps:
1. Ensure predictive_maintenance_data.csv is present
2. Run: python model_selection_training.py
