
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder, StandardScaler

# Load dataset
df = pd.read_csv("customer_churn.csv")

# Data cleaning
df['TotalCharges'] = pd.to_numeric(df['TotalCharges'], errors='coerce')
df['TotalCharges'].fillna(df['TotalCharges'].median(), inplace=True)

# EDA
sns.countplot(x='Churn', data=df)
plt.title("Churn Distribution")
plt.show()

sns.boxplot(x='Churn', y='MonthlyCharges', data=df)
plt.title("Monthly Charges vs Churn")
plt.show()

# Feature Engineering
def tenure_group(tenure):
    if tenure <= 12:
        return 'New'
    elif tenure <= 36:
        return 'Mid'
    else:
        return 'Long'

df['TenureGroup'] = df['tenure'].apply(tenure_group)
df['AvgMonthlySpend'] = df['TotalCharges'] / (df['tenure'] + 1)

services = [
    'PhoneService', 'InternetService', 'OnlineSecurity',
    'OnlineBackup', 'DeviceProtection', 'TechSupport',
    'StreamingTV', 'StreamingMovies'
]

df['ServiceCount'] = df[services].apply(lambda row: sum(row == 'Yes'), axis=1)

df['PaymentRisk'] = df['PaymentMethod'].apply(
    lambda x: 1 if 'electronic' in x.lower() else 0
)

df['SupportRisk'] = df['TechSupport'].apply(lambda x: 0 if x == 'Yes' else 1)

# Encoding
df['Churn'] = df['Churn'].map({'Yes':1, 'No':0})
le = LabelEncoder()
for col in df.select_dtypes(include='object').columns:
    df[col] = le.fit_transform(df[col])

# Scaling
scaler = StandardScaler()
num_cols = ['tenure', 'MonthlyCharges', 'TotalCharges', 'AvgMonthlySpend', 'ServiceCount']
df[num_cols] = scaler.fit_transform(df[num_cols])

# Save processed data
df.to_csv("processed_customer_churn.csv", index=False)
print("EDA and Feature Engineering completed successfully.")
