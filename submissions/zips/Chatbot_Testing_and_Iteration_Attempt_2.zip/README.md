# Test and Iterate on Chatbot Prototype – Attempt 2/3

This package contains testing artifacts and iteration notes for the chatbot prototype.
